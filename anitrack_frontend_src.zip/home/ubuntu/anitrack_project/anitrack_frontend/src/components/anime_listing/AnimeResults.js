import React from 'react';
import './AnimeResults.css';

const AnimeResults = ({ animeList }) => {
  if (!animeList || animeList.length === 0) {
    return <p className="no-results">No anime found matching your criteria.</p>;
  }

  return (
    <div className="anime-results">
      {animeList.map(anime => (
        <div key={anime.id} className="anime-card">
          <img src={anime.poster} alt={anime.title} className="anime-poster" />
          <div className="anime-info">
            <h4>{anime.title}</h4>
            <p><strong>Genre:</strong> {anime.genre}</p>
            <p><strong>Year:</strong> {anime.year}</p>
            <p><strong>Season:</strong> {anime.season}</p>
            <p><strong>Rating:</strong> {anime.rating} / 5.0</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AnimeResults;
