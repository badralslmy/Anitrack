import React, { useState } from 'react';
import './AnimeFilters.css';

const AnimeFilters = ({ onFilterChange }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [genre, setGenre] = useState('all');
  const [year, setYear] = useState('all');
  const [season, setSeason] = useState('all');
  const [rating, setRating] = useState('all');

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleGenreChange = (e) => {
    setGenre(e.target.value);
  };

  const handleYearChange = (e) => {
    setYear(e.target.value);
  };

  const handleSeasonChange = (e) => {
    setSeason(e.target.value);
  };

  const handleRatingChange = (e) => {
    setRating(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onFilterChange({ searchTerm, genre, year, season, rating });
  };

  // Mock data for dropdowns - in a real app, this might come from an API
  const genres = ['all', 'Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Sci-Fi', 'Slice of Life', 'Shounen'];
  const years = ['all', ...Array.from({ length: 15 }, (_, i) => (new Date().getFullYear() - i).toString())]; // Last 15 years
  const seasons = ['all', 'Spring', 'Summer', 'Fall', 'Winter'];
  const ratings = ['all', '5', '4', '3', '2', '1']; // Minimum rating

  return (
    <form className="anime-filters" onSubmit={handleSubmit}>
      <div className="filter-group">
        <label htmlFor="search">Search by Title:</label>
        <input 
          type="text" 
          id="search" 
          value={searchTerm} 
          onChange={handleSearchChange} 
          placeholder="Enter anime title..."
        />
      </div>

      <div className="filter-group">
        <label htmlFor="genre">Genre:</label>
        <select id="genre" value={genre} onChange={handleGenreChange}>
          {genres.map(g => <option key={g} value={g}>{g === 'all' ? 'All Genres' : g}</option>)}
        </select>
      </div>

      <div className="filter-group">
        <label htmlFor="year">Year:</label>
        <select id="year" value={year} onChange={handleYearChange}>
          {years.map(y => <option key={y} value={y}>{y === 'all' ? 'All Years' : y}</option>)}
        </select>
      </div>

      <div className="filter-group">
        <label htmlFor="season">Season:</label>
        <select id="season" value={season} onChange={handleSeasonChange}>
          {seasons.map(s => <option key={s} value={s}>{s === 'all' ? 'All Seasons' : s}</option>)}
        </select>
      </div>

      <div className="filter-group">
        <label htmlFor="rating">Min. Rating:</label>
        <select id="rating" value={rating} onChange={handleRatingChange}>
          {ratings.map(r => <option key={r} value={r}>{r === 'all' ? 'Any Rating' : `${r}+ Stars`}</option>)}
        </select>
      </div>
      
      <button type="submit">Apply Filters</button>
    </form>
  );
};

export default AnimeFilters;
