import React from 'react';
import './AnimeInfo.css';

const AnimeInfo = ({ anime }) => {
  if (!anime) {
    return <p>Loading anime information...</p>;
  }

  return (
    <div className="anime-info-container">
      <div className="anime-main-info">
        <img src={anime.verticalPoster} alt={`${anime.title} Poster`} className="anime-detail-poster" />
        <div className="anime-details">
          <h1>{anime.title}</h1>
          <div className="anime-meta">
            <span className="meta-item"><strong>Rating:</strong> {anime.rating}/10</span>
            <span className="meta-item"><strong>Studio:</strong> {anime.studio}</span>
            <span className="meta-item"><strong>Writer:</strong> {anime.writer}</span>
          </div>
          <div className="anime-genres">
            <strong>Genres:</strong>
            {anime.genres && anime.genres.map(genre => (
              <span key={genre} className="genre-tag">{genre}</span>
            ))}
          </div>
          <h3>Description</h3>
          <p className="anime-description">{anime.description}</p>
        </div>
      </div>
    </div>
  );
};

export default AnimeInfo;
