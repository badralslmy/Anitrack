import React from 'react';
import './AnimeCharacters.css';

const AnimeCharacters = ({ characters }) => {
  if (!characters || characters.length === 0) {
    return <p>No character information available.</p>;
  }

  return (
    <div className="anime-characters-container">
      <h3>Characters & Voice Actors</h3>
      <div className="characters-grid">
        {characters.map(character => (
          <div key={character.id} className="character-card">
            <img src={character.image} alt={character.name} className="character-image" />
            <div className="character-info">
              <h4>{character.name}</h4>
              {character.voiceActor && (
                <div className="voice-actor-info">
                  <img src={character.voiceActor.image} alt={character.voiceActor.name} className="va-image" />
                  <p>{character.voiceActor.name}</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AnimeCharacters;
