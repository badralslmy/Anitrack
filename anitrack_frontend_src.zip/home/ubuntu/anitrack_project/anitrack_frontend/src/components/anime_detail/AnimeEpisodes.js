import React, { useState } from 'react';
import './AnimeEpisodes.css';

const AnimeEpisodes = ({ seasons }) => {
  const [activeSeason, setActiveSeason] = useState(seasons && seasons.length > 0 ? seasons[0].id : null);

  if (!seasons || seasons.length === 0) {
    return <p>No episode information available.</p>;
  }

  const currentSeason = seasons.find(season => season.id === activeSeason);

  return (
    <div className="anime-episodes-container">
      <h3>Episodes</h3>
      <div className="season-tabs">
        {seasons.map(season => (
          <button 
            key={season.id} 
            className={`season-tab ${activeSeason === season.id ? 'active' : ''}`}
            onClick={() => setActiveSeason(season.id)}
          >
            {season.name}
          </button>
        ))}
      </div>
      {currentSeason && (
        <ul className="episode-list">
          {currentSeason.episodes.map(episode => (
            <li key={episode.id} className="episode-item">
              <span className="episode-number">Episode {episode.number}:</span>
              <span className="episode-title">{episode.title}</span>
              {/* Add watch status/link here if needed */}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AnimeEpisodes;
