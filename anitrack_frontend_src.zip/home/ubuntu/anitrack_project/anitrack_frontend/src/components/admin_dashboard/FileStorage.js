import React, { useState } from 'react';
import './FileStorage.css';

// Mock data for demonstration
const mockEpisodeLinks = [
  { id: 1, animeTitle: 'Attack on Titan S1', episodeNumber: 1, link: 'https://example.com/aot-s1-e1', status: 'active' },
  { id: 2, animeTitle: 'Attack on Titan S1', episodeNumber: 2, link: 'https://example.com/aot-s1-e2', status: 'active' },
  { id: 3, animeTitle: 'Jujutsu Kaisen S1', episodeNumber: 1, link: 'https://example.com/jjk-s1-e1', status: 'broken' },
];

const FileStorage = () => {
  const [links, setLinks] = useState(mockEpisodeLinks);
  const [newLink, setNewLink] = useState({ animeTitle: '', episodeNumber: '', link: '' });
  const [editingLink, setEditingLink] = useState(null); // To store link being edited

  const handleAddLinkChange = (e) => {
    setNewLink({ ...newLink, [e.target.name]: e.target.value });
  };

  const handleAddLinkSubmit = (e) => {
    e.preventDefault();
    const newId = links.length > 0 ? Math.max(...links.map(l => l.id)) + 1 : 1;
    setLinks([...links, { ...newLink, id: newId, status: 'active' }]);
    setNewLink({ animeTitle: '', episodeNumber: '', link: '' }); // Reset form
    alert('New link added (mock).');
  };

  const handleDeleteLink = (id) => {
    setLinks(links.filter(link => link.id !== id));
    alert('Link deleted (mock).');
  };

  const handleEditLink = (link) => {
    setEditingLink({ ...link }); // Set the link to be edited
  };

  const handleUpdateLinkChange = (e) => {
    setEditingLink({ ...editingLink, [e.target.name]: e.target.value });
  };

  const handleUpdateLinkSubmit = (e) => {
    e.preventDefault();
    setLinks(links.map(link => (link.id === editingLink.id ? editingLink : link)));
    setEditingLink(null); // Clear editing state
    alert('Link updated (mock).');
  };

  return (
    <div className="file-storage-section">
      <h4>Manage Watch Links</h4>

      <h5>Add New Link</h5>
      <form onSubmit={handleAddLinkSubmit} className="add-link-form">
        <div>
          <label htmlFor="animeTitle">Anime Title & Season:</label>
          <input type="text" id="animeTitle" name="animeTitle" value={newLink.animeTitle} onChange={handleAddLinkChange} required />
        </div>
        <div>
          <label htmlFor="episodeNumber">Episode Number:</label>
          <input type="number" id="episodeNumber" name="episodeNumber" value={newLink.episodeNumber} onChange={handleAddLinkChange} required />
        </div>
        <div>
          <label htmlFor="link">Watch Link URL:</label>
          <input type="url" id="link" name="link" value={newLink.link} onChange={handleAddLinkChange} required />
        </div>
        <button type="submit">Add Link</button>
      </form>

      {editingLink && (
        <div className="edit-link-form-container">
          <h5>Edit Link (ID: {editingLink.id})</h5>
          <form onSubmit={handleUpdateLinkSubmit} className="edit-link-form">
            <div>
              <label htmlFor="editAnimeTitle">Anime Title & Season:</label>
              <input type="text" id="editAnimeTitle" name="animeTitle" value={editingLink.animeTitle} onChange={handleUpdateLinkChange} required />
            </div>
            <div>
              <label htmlFor="editEpisodeNumber">Episode Number:</label>
              <input type="number" id="editEpisodeNumber" name="episodeNumber" value={editingLink.episodeNumber} onChange={handleUpdateLinkChange} required />
            </div>
            <div>
              <label htmlFor="editLink">Watch Link URL:</label>
              <input type="url" id="editLink" name="link" value={editingLink.link} onChange={handleUpdateLinkChange} required />
            </div>
            <div>
              <label htmlFor="editStatus">Status:</label>
              <select name="status" value={editingLink.status} onChange={handleUpdateLinkChange}>
                <option value="active">Active</option>
                <option value="broken">Broken</option>
                <option value="pending">Pending</option>
              </select>
            </div>
            <button type="submit">Update Link</button>
            <button type="button" onClick={() => setEditingLink(null)}>Cancel</button>
          </form>
        </div>
      )}

      <h5>Existing Links</h5>
      <table className="links-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Anime Title</th>
            <th>Episode</th>
            <th>Link URL</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {links.map(link => (
            <tr key={link.id}>
              <td>{link.id}</td>
              <td>{link.animeTitle}</td>
              <td>{link.episodeNumber}</td>
              <td><a href={link.link} target="_blank" rel="noopener noreferrer">{link.link}</a></td>
              <td className={`status-${link.status}`}>{link.status}</td>
              <td>
                <button onClick={() => handleEditLink(link)} className="edit-btn">Edit</button>
                <button onClick={() => handleDeleteLink(link.id)} className="delete-btn">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default FileStorage;

