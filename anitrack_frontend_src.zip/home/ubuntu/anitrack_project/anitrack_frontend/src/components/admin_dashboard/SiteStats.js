import React from 'react';
import './SiteStats.css';

// Mock data for demonstration
const mockSiteStats = {
  totalUsers: 1250,
  totalAnime: 3500,
  totalRatings: 150000,
  mostFollowedAnime: [
    { id: 1, title: 'Attack on Titan', followers: 980 },
    { id: 2, title: 'Jujutsu Kaisen', followers: 950 },
    { id: 3, title: 'Demon Slayer', followers: 920 },
  ],
};

const SiteStats = () => {
  return (
    <div className="site-stats-section">
      <h4>Site Statistics</h4>
      <div className="stats-overview">
        <div className="stat-item"><strong>Total Users:</strong> {mockSiteStats.totalUsers.toLocaleString()}</div>
        <div className="stat-item"><strong>Total Anime Series:</strong> {mockSiteStats.totalAnime.toLocaleString()}</div>
        <div className="stat-item"><strong>Total Ratings Submitted:</strong> {mockSiteStats.totalRatings.toLocaleString()}</div>
      </div>
      <h5>Most Followed Anime</h5>
      <ul className="most-followed-list">
        {mockSiteStats.mostFollowedAnime.map(anime => (
          <li key={anime.id}>{anime.title} - {anime.followers.toLocaleString()} followers</li>
        ))}
      </ul>
      {/* More detailed charts or data could be added here */}
    </div>
  );
};

export default SiteStats;
