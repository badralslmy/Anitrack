import React, { useState } from 'react';
import './DatabaseManager.css';

// Mock data - in a real app, this would interact with a backend API
const initialData = {
  anime: [
    { id: 1, title: 'Attack on Titan', genre: 'Action', year: 2013 },
    { id: 2, title: 'Jujutsu Kaisen', genre: 'Action', year: 2020 },
  ],
  episodes: [
    { id: 101, anime_id: 1, title: 'To You, in 2000 Years: The Fall of Shiganshina, Part 1', number: 1 },
    { id: 102, anime_id: 1, title: 'That Day: The Fall of Shiganshina, Part 2', number: 2 },
  ],
  users: [
    { id: 1, username: 'admin_user', email: 'admin@example.com' },
    { id: 2, username: 'test_user', email: 'test@example.com' },
  ],
  genres: [
    { id: 1, name: 'Action' },
    { id: 2, name: 'Adventure' },
    { id: 3, name: 'Comedy' },
  ],
  voices: [ // Assuming this means voice actors or similar
    { id: 1, name: 'Yuki Kaji', character_id: 1 },
    { id: 2, name: 'Yui Ishikawa', character_id: 2 },
  ]
};

const CrudSection = ({ title, items, setItems, fields }) => {
  const [newItem, setNewItem] = useState({});
  const [editingItem, setEditingItem] = useState(null);

  const handleAddChange = (e) => {
    setNewItem({ ...newItem, [e.target.name]: e.target.value });
  };

  const handleAddSubmit = (e) => {
    e.preventDefault();
    const newId = items.length > 0 ? Math.max(...items.map(i => i.id)) + 1 : 1;
    setItems([...items, { ...newItem, id: newId }]);
    setNewItem({});
    alert(`${title.slice(0, -1)} added (mock).`);
  };

  const handleDelete = (id) => {
    setItems(items.filter(item => item.id !== id));
    alert(`${title.slice(0, -1)} deleted (mock).`);
  };

  const handleEdit = (item) => {
    setEditingItem({ ...item });
  };

  const handleUpdateChange = (e) => {
    setEditingItem({ ...editingItem, [e.target.name]: e.target.value });
  };

  const handleUpdateSubmit = (e) => {
    e.preventDefault();
    setItems(items.map(item => (item.id === editingItem.id ? editingItem : item)));
    setEditingItem(null);
    alert(`${title.slice(0, -1)} updated (mock).`);
  };

  return (
    <div className="crud-section">
      <h5>Manage {title}</h5>
      <form onSubmit={handleAddSubmit} className="add-item-form">
        <h6>Add New {title.slice(0, -1)}</h6>
        {fields.map(field => (
          <div key={field.name}>
            <label htmlFor={`add-${field.name}`}>{field.label}:</label>
            <input type={field.type} id={`add-${field.name}`} name={field.name} value={newItem[field.name] || ''} onChange={handleAddChange} required />
          </div>
        ))}
        <button type="submit">Add {title.slice(0, -1)}</button>
      </form>

      {editingItem && (
        <form onSubmit={handleUpdateSubmit} className="edit-item-form">
          <h6>Edit {title.slice(0, -1)} (ID: {editingItem.id})</h6>
          {fields.map(field => (
            <div key={field.name}>
              <label htmlFor={`edit-${field.name}`}>{field.label}:</label>
              <input type={field.type} id={`edit-${field.name}`} name={field.name} value={editingItem[field.name] || ''} onChange={handleUpdateChange} required />
            </div>
          ))}
          <button type="submit">Update {title.slice(0, -1)}</button>
          <button type="button" onClick={() => setEditingItem(null)}>Cancel</button>
        </form>
      )}

      <h6>Existing {title}</h6>
      <table className="data-table">
        <thead>
          <tr>
            <th>ID</th>
            {fields.map(field => <th key={field.name}>{field.label}</th>)}
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {items.map(item => (
            <tr key={item.id}>
              <td>{item.id}</td>
              {fields.map(field => <td key={field.name}>{item[field.name]}</td>)}
              <td>
                <button onClick={() => handleEdit(item)} className="edit-btn">Edit</button>
                <button onClick={() => handleDelete(item.id)} className="delete-btn">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const DatabaseManager = () => {
  const [animeData, setAnimeData] = useState(initialData.anime);
  const [episodeData, setEpisodeData] = useState(initialData.episodes);
  const [userData, setUserData] = useState(initialData.users);
  const [genreData, setGenreData] = useState(initialData.genres);
  const [voiceData, setVoiceData] = useState(initialData.voices);

  const animeFields = [
    { name: 'title', label: 'Title', type: 'text' },
    { name: 'genre', label: 'Genre', type: 'text' },
    { name: 'year', label: 'Year', type: 'number' },
  ];
  const episodeFields = [
    { name: 'anime_id', label: 'Anime ID', type: 'number' },
    { name: 'title', label: 'Title', type: 'text' },
    { name: 'number', label: 'Episode Number', type: 'number' },
  ];
  const userFields = [
    { name: 'username', label: 'Username', type: 'text' },
    { name: 'email', label: 'Email', type: 'email' },
  ];
  const genreFields = [
    { name: 'name', label: 'Name', type: 'text' },
  ];
  const voiceFields = [
    { name: 'name', label: 'Voice Actor Name', type: 'text' },
    { name: 'character_id', label: 'Character ID', type: 'number' },
  ];


  return (
    <div className="database-manager-section">
      <h4>Database Management (CRUD Interface)</h4>
      <CrudSection title="Anime" items={animeData} setItems={setAnimeData} fields={animeFields} />
      <CrudSection title="Episodes" items={episodeData} setItems={setEpisodeData} fields={episodeFields} />
      <CrudSection title="Users" items={userData} setItems={setUserData} fields={userFields} />
      <CrudSection title="Genres" items={genreData} setItems={setGenreData} fields={genreFields} />
      <CrudSection title="Voices" items={voiceData} setItems={setVoiceData} fields={voiceFields} />
    </div>
  );
};

export default DatabaseManager;

