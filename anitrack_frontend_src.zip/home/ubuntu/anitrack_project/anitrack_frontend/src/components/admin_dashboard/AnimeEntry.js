import React, { useState } from 'react';
import './AnimeEntry.css';

const AnimeEntry = () => {
  const [manualEntry, setManualEntry] = useState({});
  const [apiImportUrl, setApiImportUrl] = useState('');

  const handleManualChange = (e) => {
    setManualEntry({ ...manualEntry, [e.target.name]: e.target.value });
  };

  const handleManualSubmit = (e) => {
    e.preventDefault();
    // Logic to submit manual entry (e.g., to backend API)
    console.log('Submitting manual entry:', manualEntry);
    alert('Manual entry submitted (mock).');
  };

  const handleApiImportChange = (e) => {
    setApiImportUrl(e.target.value);
  };

  const handleApiImportSubmit = (e) => {
    e.preventDefault();
    // Logic to import from API (e.g., fetch from MyAnimeList/AniList)
    console.log('Importing from API URL:', apiImportUrl);
    alert('API import initiated (mock).');
  };

  return (
    <div className="anime-entry-section">
      <h4>Add New Anime</h4>
      <div className="entry-forms">
        <form onSubmit={handleManualSubmit} className="manual-entry-form">
          <h5>Manual Entry</h5>
          {/* Add form fields for manual anime details here */}
          <div>
            <label htmlFor="title">Title:</label>
            <input type="text" id="title" name="title" onChange={handleManualChange} required />
          </div>
          <div>
            <label htmlFor="description">Description:</label>
            <textarea id="description" name="description" onChange={handleManualChange} required />
          </div>
          {/* Add more fields: genres, rating, studio, writer, posters etc. */}
          <button type="submit">Add Anime Manually</button>
        </form>

        <form onSubmit={handleApiImportSubmit} className="api-import-form">
          <h5>Import from API</h5>
          <div>
            <label htmlFor="api_url">API URL (e.g., MyAnimeList/AniList):</label>
            <input type="url" id="api_url" name="api_url" value={apiImportUrl} onChange={handleApiImportChange} placeholder="Enter API URL..." required />
          </div>
          <button type="submit">Import from API</button>
        </form>
      </div>
    </div>
  );
};

export default AnimeEntry;
