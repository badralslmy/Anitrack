import React from 'react';
import './MyAnimeLists.css';

const AnimeListSection = ({ title, animeItems }) => {
  if (!animeItems || animeItems.length === 0) {
    return null; // Don't render section if no items
  }
  return (
    <div className="anime-list-section">
      <h4>{title}</h4>
      <ul>
        {animeItems.map(anime => (
          <li key={anime.id}>
            {anime.title}
            {anime.progress && <span className="progress"> - {anime.progress}</span>}
            {anime.score && <span className="score"> - Score: {anime.score}/10</span>}
          </li>
        ))}
      </ul>
    </div>
  );
};

const MyAnimeLists = ({ userAnimeData }) => {
  if (!userAnimeData) {
    return <p>Loading your anime lists...</p>;
  }

  return (
    <div className="my-anime-lists">
      <h3>Your Anime Collections</h3>
      <AnimeListSection title="Watching Now" animeItems={userAnimeData.watchingNow} />
      <AnimeListSection title="Want to Watch" animeItems={userAnimeData.wantToWatch} />
      <AnimeListSection title="Watch Later" animeItems={userAnimeData.watchLater} />
      <AnimeListSection title="Completed" animeItems={userAnimeData.completed} />
      <AnimeListSection title="Not Interested" animeItems={userAnimeData.notInterested} />
    </div>
  );
};

export default MyAnimeLists;
