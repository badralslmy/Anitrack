import React from 'react';
import { PieChart, Pie, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import './MyAnimeStats.css';

const MyAnimeStats = ({ stats }) => {
  if (!stats || !stats.pieChartData || !stats.barChartData) {
    return <p>Loading stats...</p>;
  }

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF'];

  return (
    <div className="my-anime-stats">
      <h3>Your Anime Statistics</h3>
      <div className="charts-container">
        <div className="chart-wrapper">
          <h4>Status Distribution (Pie Chart)</h4>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={stats.pieChartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
                nameKey="name"
                label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
              >
                {stats.pieChartData.map((entry, index) => (
                  <text key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="chart-wrapper">
          <h4>Status Counts (Bar Chart)</h4>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={stats.barChartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default MyAnimeStats;
