import React, { useState, useEffect } from 'react';
import './ContentSections.css';

const ContentSections = () => {
  const allSections = [
    { id: 'countdown', title: 'Countdown to Next Episodes', content: 'Details about upcoming episodes...' },
    { id: 'top10', title: 'Top 10 Anime', content: 'List of top 10 anime...' },
    { id: 'recommendations', title: 'Personalized Suggestions', content: 'Anime recommended for you...' },
    { id: 'continue_watching', title: 'Continue Watching', content: 'Resume your recently watched anime...' },
    { id: 'new_episodes', title: 'New Episodes', content: 'Latest episodes added...' },
    { id: 'new_anime', title: 'New Anime', content: 'Recently added anime series...' },
  ];

  const [shuffledSections, setShuffledSections] = useState([]);

  useEffect(() => {
    // Fisher-Yates shuffle algorithm
    let array = [...allSections];
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    setShuffledSections(array);
  }, []); // Empty dependency array means this runs once on mount

  if (shuffledSections.length === 0) {
    return <div className="content-sections-loading">Loading sections...</div>;
  }

  return (
    <div className="content-sections">
      {shuffledSections.map(section => (
        <section key={section.id} className={`content-section content-section-${section.id}`}>
          <h3>{section.title}</h3>
          <p>{section.content}</p>
        </section>
      ))}
    </div>
  );
};

export default ContentSections;
