import React, { useState, useEffect } from 'react';
import './HeroBanner.css';

const HeroBanner = () => {
  const [heroItem, setHeroItem] = useState(null);

  const heroItems = [
    {
      id: 1,
      type: 'countdown',
      title: 'Attack on Titan - Final Season Part 3',
      message: 'Next episode in: 2 days 10 hours 30 minutes',
    },
    {
      id: 2,
      type: 'recommendation',
      title: 'Recommendation: Spy x Family',
      message: 'A thrilling and heartwarming story of a spy, an assassin, and a telepath.',
    },
    {
      id: 3,
      type: 'rating_invite',
      title: 'Rate: Jujutsu Kaisen 0 Movie',
      message: 'You watched this, how would you rate it?',
    },
    {
      id: 4,
      type: 'top_5_user',
      title: 'Your Top 5 Anime',
      message: '1. Fullmetal Alchemist: Brotherhood, 2. Steins;Gate, 3. Gintama, 4. Hunter x Hunter (2011), 5. Code Geass',
    },
    {
      id: 5,
      type: 'incomplete',
      title: 'Continue Watching: Vinland Saga',
      message: 'You are on Season 2, Episode 5. Keep going!',
    },
  ];

  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * heroItems.length);
    setHeroItem(heroItems[randomIndex]);
  }, []); // Empty dependency array means this runs once on mount

  if (!heroItem) {
    return <div className="hero-banner-loading">Loading...</div>;
  }

  return (
    <section className="hero-banner">
      <div className={`hero-item hero-item-${heroItem.type}`}>
        <h2>{heroItem.title}</h2>
        <p>{heroItem.message}</p>
        {/* Add more specific rendering based on type if needed */}
      </div>
    </section>
  );
};

export default HeroBanner;
