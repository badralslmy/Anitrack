import React, { useState } from 'react';
import './AdminDashboardPage.css';
import AnimeEntry from '../../components/admin_dashboard/AnimeEntry';
import SiteStats from '../../components/admin_dashboard/SiteStats';
import FileStorage from '../../components/admin_dashboard/FileStorage';
import DatabaseManager from '../../components/admin_dashboard/DatabaseManager';

const AdminDashboardPage = () => {
  const [activeTab, setActiveTab] = useState('animeEntry'); // Default tab

  const renderActiveTabContent = () => {
    switch (activeTab) {
      case 'animeEntry':
        return <AnimeEntry />;
      case 'siteStats':
        return <SiteStats />;
      case 'fileStorage':
        return <FileStorage />;
      case 'databaseManager':
        return <DatabaseManager />;
      default:
        return <p>Select a section</p>;
    }
  };

  return (
    <div className="admin-dashboard-page">
      <h2>Admin Dashboard</h2>
      <nav className="admin-nav">
        <button onClick={() => setActiveTab('animeEntry')} className={activeTab === 'animeEntry' ? 'active' : ''}>Anime Entry</button>
        <button onClick={() => setActiveTab('siteStats')} className={activeTab === 'siteStats' ? 'active' : ''}>Site Statistics</button>
        <button onClick={() => setActiveTab('fileStorage')} className={activeTab === 'fileStorage' ? 'active' : ''}>File Storage (Watch Links)</button>
        <button onClick={() => setActiveTab('databaseManager')} className={activeTab === 'databaseManager' ? 'active' : ''}>Database Management</button>
      </nav>
      <div className="admin-content">
        {renderActiveTabContent()}
      </div>
    </div>
  );
};

export default AdminDashboardPage;
