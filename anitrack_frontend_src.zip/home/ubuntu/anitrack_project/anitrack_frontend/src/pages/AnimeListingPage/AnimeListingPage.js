import React from 'react';
import AnimeFilters from '../../components/anime_listing/AnimeFilters';
import AnimeResults from '../../components/anime_listing/AnimeResults';
import './AnimeListingPage.css';

const AnimeListingPage = () => {
  // Mock data for now, will be replaced with API calls
  const mockAnimeData = Array.from({ length: 300 }, (_, i) => ({
    id: i + 1,
    title: `Anime Title ${i + 1}`,
    genre: ['Action', 'Adventure', 'Fantasy', 'Shounen'][Math.floor(Math.random() * 4)],
    year: 2020 + Math.floor(Math.random() * 5),
    season: ['Spring', 'Summer', 'Fall', 'Winter'][Math.floor(Math.random() * 4)],
    rating: (Math.random() * 5).toFixed(1),
    poster: `https://via.placeholder.com/150/0000FF/808080?Text=Anime+${i+1}`
  }));

  const [filteredAnime, setFilteredAnime] = React.useState(mockAnimeData);
  const [currentPage, setCurrentPage] = React.useState(1);
  const itemsPerPage = 100;

  const handleFilterChange = (filters) => {
    console.log('Filters applied:', filters);
    // Basic filtering logic (example)
    let tempAnime = mockAnimeData;
    if (filters.searchTerm) {
      tempAnime = tempAnime.filter(anime => 
        anime.title.toLowerCase().includes(filters.searchTerm.toLowerCase())
      );
    }
    if (filters.genre && filters.genre !== 'all') {
      tempAnime = tempAnime.filter(anime => anime.genre === filters.genre);
    }
    if (filters.year && filters.year !== 'all') {
      tempAnime = tempAnime.filter(anime => anime.year === parseInt(filters.year));
    }
    if (filters.season && filters.season !== 'all') {
      tempAnime = tempAnime.filter(anime => anime.season === filters.season);
    }
    if (filters.rating && filters.rating !== 'all') {
      tempAnime = tempAnime.filter(anime => parseFloat(anime.rating) >= parseFloat(filters.rating));
    }
    setFilteredAnime(tempAnime);
    setCurrentPage(1); // Reset to first page on filter change
  };

  const totalPages = Math.ceil(filteredAnime.length / itemsPerPage);
  const currentAnimeData = filteredAnime.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="anime-listing-page">
      <h2>Anime List</h2>
      <AnimeFilters onFilterChange={handleFilterChange} />
      <AnimeResults animeList={currentAnimeData} />
      {/* Basic Pagination */} 
      <div className="pagination">
        {Array.from({ length: totalPages }, (_, i) => i + 1).map(pageNumber => (
          <button 
            key={pageNumber} 
            onClick={() => setCurrentPage(pageNumber)}
            className={currentPage === pageNumber ? 'active' : ''}
          >
            {pageNumber}
          </button>
        ))}
      </div>
    </div>
  );
};

export default AnimeListingPage;
