import React from 'react';
import './MyListPage.css';
import MyAnimeStats from '../../components/my_list/MyAnimeStats';
import MyAnimeLists from '../../components/my_list/MyAnimeLists';

// Mock data for demonstration
const mockUserAnimeData = {
  watchingNow: [
    { id: 101, title: 'One Piece', progress: 'Episode 1050' },
    { id: 102, title: 'Bleach: Thousand-Year Blood War', progress: 'Episode 10' },
  ],
  wantToWatch: [
    { id: 201, title: 'Chainsaw Man Season 2' },
    { id: 202, title: 'Oshi no Ko Season 2' },
    { id: 203, title: 'Mushoku Tensei: Jobless Reincarnation Season 3' },
  ],
  watchLater: [
    { id: 301, title: 'Cyberpunk: Edgerunners' },
  ],
  notInterested: [
    { id: 401, title: 'Some Other Anime I Dropped' },
  ],
  completed: [
    { id: 501, title: 'Fullmetal Alchemist: Brotherhood', score: 10 },
    { id: 502, title: 'Steins;Gate', score: 9 },
    { id: 503, title: 'Attack on Titan', score: 9 },
    { id: 504, title: 'Death Note', score: 8 },
    { id: 505, title: 'Code Geass', score: 9 },
  ],
};

const MyListPage = () => {
  const statsData = {
    pieChartData: [
      { name: 'Watching Now', value: mockUserAnimeData.watchingNow.length },
      { name: 'Want to Watch', value: mockUserAnimeData.wantToWatch.length },
      { name: 'Watch Later', value: mockUserAnimeData.watchLater.length },
      { name: 'Not Interested', value: mockUserAnimeData.notInterested.length },
      { name: 'Completed', value: mockUserAnimeData.completed.length },
    ],
    barChartData: [
      { name: 'Watching', count: mockUserAnimeData.watchingNow.length },
      { name: 'Planned', count: mockUserAnimeData.wantToWatch.length },
      { name: 'Later', count: mockUserAnimeData.watchLater.length },
      { name: 'Dropped', count: mockUserAnimeData.notInterested.length },
      { name: 'Finished', count: mockUserAnimeData.completed.length },
    ],
  };

  return (
    <div className="my-list-page">
      <h2>My Anime List</h2>
      <MyAnimeStats stats={statsData} />
      <MyAnimeLists userAnimeData={mockUserAnimeData} />
    </div>
  );
};

export default MyListPage;
