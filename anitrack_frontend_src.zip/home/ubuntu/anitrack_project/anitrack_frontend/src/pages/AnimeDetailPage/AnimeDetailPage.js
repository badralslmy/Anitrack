import React from 'react';
import './AnimeDetailPage.css';
import AnimeInfo from '../../components/anime_detail/AnimeInfo';
import AnimeEpisodes from '../../components/anime_detail/AnimeEpisodes';
import AnimeCharacters from '../../components/anime_detail/AnimeCharacters';

// Mock data for demonstration
const mockAnimeData = {
  id: 1,
  title: 'Attack on Titan',
  horizontalBanner: 'https://via.placeholder.com/1200x400/0000FF/FFFFFF?text=Attack+on+Titan+Banner',
  verticalPoster: 'https://via.placeholder.com/300x450/0000FF/FFFFFF?text=Attack+on+Titan+Poster',
  description: 'Several hundred years ago, humans were nearly exterminated by giants. Giants are typically several stories tall, seem to have no intelligence, devour human beings and, worst of all, seem to do it for the pleasure rather than as a food source. A small percentage of humanity survived by walling themselves in a city protected by extremely high walls, even taller than the biggest of giants.',
  genres: ['Action', 'Drama', 'Fantasy', 'Military', 'Mystery', 'Shounen', 'Super Power'],
  rating: 9.1,
  studio: 'Wit Studio',
  writer: 'Hajime Isayama',
  seasons: [
    {
      id: 1,
      name: 'Season 1',
      episodes: Array.from({ length: 25 }, (_, i) => ({
        id: i + 1,
        number: i + 1,
        title: `Episode ${i + 1}`,
      })),
    },
    {
      id: 2,
      name: 'Season 2',
      episodes: Array.from({ length: 12 }, (_, i) => ({
        id: 26 + i,
        number: i + 1,
        title: `Episode ${i + 1}`,
      })),
    },
    {
      id: 3,
      name: 'Season 3 Part 1',
      episodes: Array.from({ length: 12 }, (_, i) => ({
        id: 38 + i,
        number: i + 1,
        title: `Episode ${i + 1}`,
      })),
    },
    {
      id: 4,
      name: 'Season 3 Part 2',
      episodes: Array.from({ length: 10 }, (_, i) => ({
        id: 50 + i,
        number: i + 1,
        title: `Episode ${i + 1}`,
      })),
    },
  ],
  characters: [
    {
      id: 1,
      name: 'Eren Yeager',
      image: 'https://via.placeholder.com/150/0000FF/FFFFFF?text=Eren',
      voiceActor: {
        name: 'Yuki Kaji',
        image: 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Yuki+Kaji',
      },
    },
    {
      id: 2,
      name: 'Mikasa Ackerman',
      image: 'https://via.placeholder.com/150/0000FF/FFFFFF?text=Mikasa',
      voiceActor: {
        name: 'Yui Ishikawa',
        image: 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Yui+Ishikawa',
      },
    },
    {
      id: 3,
      name: 'Armin Arlert',
      image: 'https://via.placeholder.com/150/0000FF/FFFFFF?text=Armin',
      voiceActor: {
        name: 'Marina Inoue',
        image: 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Marina+Inoue',
      },
    },
    {
      id: 4,
      name: 'Levi Ackerman',
      image: 'https://via.placeholder.com/150/0000FF/FFFFFF?text=Levi',
      voiceActor: {
        name: 'Hiroshi Kamiya',
        image: 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Hiroshi+Kamiya',
      },
    },
  ],
};

const AnimeDetailPage = () => {
  return (
    <div className="anime-detail-page">
      <div className="anime-banner" style={{ backgroundImage: `url(${mockAnimeData.horizontalBanner})` }}>
        <div className="banner-overlay"></div>
      </div>
      <div className="anime-content">
        <AnimeInfo anime={mockAnimeData} />
        <AnimeEpisodes seasons={mockAnimeData.seasons} />
        <AnimeCharacters characters={mockAnimeData.characters} />
      </div>
    </div>
  );
};

export default AnimeDetailPage;
