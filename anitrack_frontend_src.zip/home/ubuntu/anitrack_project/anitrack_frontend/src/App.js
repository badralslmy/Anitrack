import React from 'react';
import './App.css';
import HeroBanner from './components/HeroBanner';
import ContentSections from './components/ContentSections';
import AnimeListingPage from './pages/AnimeListingPage/AnimeListingPage';
import MyListPage from './pages/MyListPage/MyListPage';
import AnimeDetailPage from './pages/AnimeDetailPage/AnimeDetailPage';
import AdminDashboardPage from './pages/AdminDashboardPage/AdminDashboardPage'; // Import AdminDashboardPage
import logo from './assets/logo.png';

function App() {
  const [currentPage, setCurrentPage] = React.useState('home'); // 'home', 'anime-listing', 'my-list', 'anime-detail', 'admin-dashboard'

  let pageContent;
  if (currentPage === 'home') {
    pageContent = (
      <>
        <HeroBanner />
        <ContentSections />
      </>
    );
  } else if (currentPage === 'anime-listing') {
    pageContent = <AnimeListingPage />;
  } else if (currentPage === 'my-list') {
    pageContent = <MyListPage />;
  } else if (currentPage === 'anime-detail') {
    pageContent = <AnimeDetailPage />;
  } else if (currentPage === 'admin-dashboard') { // Add condition for Admin Dashboard
    pageContent = <AdminDashboardPage />;
  }

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="Anitrack Logo" />
        <h1>Anitrack</h1>
        <nav>
          <button onClick={() => setCurrentPage('home')}>Home</button>
          <button onClick={() => setCurrentPage('anime-listing')}>Anime List</button>
          <button onClick={() => setCurrentPage('my-list')}>My List</button>
          <button onClick={() => setCurrentPage('anime-detail')}>Anime Detail (Test)</button>
          <button onClick={() => setCurrentPage('admin-dashboard')}>Admin Dashboard</button> {/* Add button for Admin Dashboard */}
        </nav>
      </header>
      <main>
        {pageContent}
      </main>
      <footer>
        <p>&copy; 2025 Anitrack. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;
